<?php

/**
 * Mongolian PHPMailer language file: refer to English translation for definitive list
 * @package PHPMailer
 * @author @wispas
 */

$PHPMAILER_LANG['authenticate']         = 'Алдаа SMTP: Холбогдож чадсангүй.';
$PHPMAILER_LANG['connect_host']         = 'Алдаа SMTP: SMTP- сервертэй холбогдож болохгүй байна.';
$PHPMAILER_LANG['data_not_accepted']    = 'Алдаа SMTP: зөвшөөрөгдсөнгүй.';
$PHPMAILER_LANG['encoding']             = 'Тодорхойгүй кодчилол: ';
$PHPMAILER_LANG['execute']              = 'Коммандыг гүйцэтгэх боломжгүй байна: ';
$PHPMAILER_LANG['file_access']          = 'Файлд хандах боломжгүй байна: ';
$PHPMAILER_LANG['file_open']            = 'Файлын алдаа: файлыг нээх боломжгүй байна: ';
$PHPMAILER_LANG['from_failed']          = 'Илгээгчийн хаяг буруу байна: ';
$PHPMAILER_LANG['instantiate']          = 'Mail () функцийг ажиллуулах боломжгүй байна.';
$PHPMAILER_LANG['provide_address']      = 'Хүлээн авагчийн имэйл хаягийг оруулна уу.';
$PHPMAILER_LANG['mailer_not_supported'] = ' — мэйл серверийг дэмжсэнгүй.';
$PHPMAILER_LANG['recipients_failed']    = 'Алдаа SMTP: ийм хаягийг илгээж чадсангүй: ';
$PHPMAILER_LANG['empty_message']        = 'Хоосон мессэж';
$PHPMAILER_LANG['invalid_address']      = 'И-Мэйл буруу форматтай тул илгээх боломжгүй: ';
$PHPMAILER_LANG['signing']              = 'Гарын үсгийн алдаа: ';
$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP сервертэй холбогдоход алдаа гарлаа';
$PHPMAILER_LANG['smtp_error']           = 'SMTP серверийн алдаа: ';
$PHPMAILER_LANG['variable_set']         = 'Хувьсагчийг тохируулах эсвэл дахин тохируулах боломжгүй байна: ';
$PHPMAILER_LANG['extension_missing']    = 'Өргөтгөл байхгүй: ';
